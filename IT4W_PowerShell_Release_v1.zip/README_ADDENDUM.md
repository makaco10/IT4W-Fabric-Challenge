## Publicación y ejecución automatizada (PowerShell)

Las definiciones de Microsoft Fabric se versionan en `fabric/`. Como complemento de la ejecución manual, `deploy/Invoke-IT4W.ps1` implementa un release liviano con validación offline, plan de Git, actualización protegida del workspace y ejecución controlada de pipelines.

```powershell
az login --allow-no-subscriptions
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action Validate
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action Plan
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action All -Apply
```

El comando `All` funciona sobre un workspace y gateway **preconfigurados**; no aprovisiona Docker, SQL Server, tenant ni capacity. Requiere corregir actividades inactivas en las definiciones publicadas y tener el acceso correspondiente. Consultar [`deploy/README.md`](deploy/README.md) para detalles, restricciones y comandos de validación. Para validaciones funcionales ejecutar las seis consultas de `NB_Consultas_Control` y comparar dos cargas completas.
