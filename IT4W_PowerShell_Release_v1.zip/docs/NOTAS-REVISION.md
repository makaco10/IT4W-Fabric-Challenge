# Revisión previa a la entrega (23-10-2026)

1. **Repo visible:** `makaco10/IT4W-Fabric-Challenge`, `main`, `fabric/` con notebooks y pipelines.
2. **Pipeline histórico versionado:** actividad `FE_BF_Fuentes` marcada `Inactive`; notebook de ingesta `NB_01_Landing_To_Bronze` también `Inactive`. La definicion de Git no garantiza la misma configuración que tu workspace.
3. **Pipeline incremental versionado:** `FE_BF_Fuentes` y `NB_IT4W_11_Landing_To_Bronze_Incremental` marcados `Inactive`.
4. **Notebook 12:** versionado en `fabric/68aacca2-4ff5-9079-4c48-d05fa4551c24.Notebook/`, `.platform` indica `NB_IT4W_12_Bronze_To_Silver_Incremental`.
5. **Consultas SQL:** `fabric/NB_Consultas_Control.Notebook/notebook-content.sql`, las 6 consultas están presentes. En el markdown de la tercera consulta hay un título escrito como "2."; corregir numeración cosmética.
6. **Documentación:** en `docs/01-Solution-Architecture.md` todavía se menciona `PL_IT4W_Ingesta_Periodica`; el nombre real versionado es `PL_IT4W_Incremental_Mensual`.
7. **Puesta en marcha reproducible:** este release cubre sincronización + ejecución en un entorno existente, **no** la creación de SQL Docker y gateway. El README principal tiene que distinguir ambas cosas.
8. **Pruebas pendientes:** ejecutar el runner PowerShell en Windows y validar autenticación, permisos y estado de jobs contra Fabric. No afirmar que el deploy está probado solo por empaquetarlo.
