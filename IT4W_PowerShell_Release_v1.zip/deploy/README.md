# IT4W — mini-release de Microsoft Fabric con PowerShell

Este paquete reproduce el **ciclo de publicación y ejecución** de la solución Nexo Retail sobre un **workspace existente** de Microsoft Fabric conectado al repositorio `makaco10/IT4W-Fabric-Challenge` (rama `main`, carpeta `fabric`). Está pensado como una demostración práctica de un release tipo Azure DevOps, **sin Azure DevOps ni Terraform**.

**No es un provisionador desde cero:** no instala Docker/SQL Server, no restaura los CSV, no aprovisiona el tenant, capacity, gateway, OneLake, Lakehouse ni conexiones. La ingesta requiere el SQL Server y gateway existentes, además de permisos en Fabric y conectividad a Frankfurter. Para reproducir desde un entorno virgen hay que documentar esos prerrequisitos y automatizar la creación del origen aparte.

## Requisitos

- Windows + **PowerShell 7** (`pwsh`).
- Azure CLI (`az`) y credenciales Microsoft Entra con permisos de lectura, ejecución y actualización Git en el workspace (según acción).
- Workspace **ya conectado y con integración Git inicializada** a la rama y subcarpeta indicadas en `config.example.json`.
- Fabric capacity activa, dependencias de notebooks resueltas, conexiones SQL Server/Gateway creadas.
- Los archivos de `deploy/` se copian **dentro de la raíz de tu clon** de `IT4W-Fabric-Challenge`. El script busca la carpeta `fabric/` un nivel arriba.
- `config.example.json` solo contiene identificadores públicos del workspace y nombres; no contiene secretos ni claves. Revisar el `workspaceId` antes de ejecutar. No guardar tokens en el repositorio.

## Comandos (desde la raíz del repositorio)

```powershell
az login --allow-no-subscriptions
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action Validate
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action Plan
# Solo cuando Validate/Plan estan en verde y Fabric/Git ya estan sincronizados:
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action Deploy -Apply
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action Run -Pipeline Incremental -Apply
# Re-ejecutar la ingesta historica y mensual (puede tardar y consumir capacidad):
pwsh -File ./deploy/Invoke-IT4W.ps1 -Action All -Apply
```

- `Validate`: **sin conexión**. Comprueba que los pipelines, notebook de controles y notebooks 00/01/02/03/11/12/13 estén exportados. **Falla si cualquier actividad está marcada `Inactive`**.
- `Plan`: **solo lectura**. Consulta el estado Git en Fabric y bloquea conflictos, cambios no publicados en el workspace y borrados remotos.
- `Deploy`: si el plan está limpio y se usa `-Apply`, llama `updateFromGit`. En ningún caso realiza commit a GitHub o resuelve conflictos automáticamente. **No crea un workspace nuevo**.
- `Run`: busca por nombre los pipelines y los ejecuta con Fabric REST; espera confirmación de éxito. Por defecto solo incremental.
- `All`: sincroniza y ejecuta **histórico → incremental** (solo con `-Apply`).

La API utilizada para ejecutar `DataPipeline` es `POST /v1/workspaces/{id}/dataPipelines/{pipelineId}/jobs/execute/instances`, que no acepta en esta operación los parámetros del pipeline; la carga mensual usa el valor `p_periodo` **configurado en Fabric**, actualmente `2026-01` según el JSON de Git. Para otro mes debe ajustarse el parámetro y validarse nuevamente la versión. No se envían parámetros inventados.

## Validaciones de negocio (separadas del deploy)

El notebook `fabric/NB_Consultas_Control.Notebook/notebook-content.sql` contiene las **6 consultas** requeridas. Para la consulta 6 se debe ejecutar dos veces el pipeline completo y registrar la cuenta de `gold.fact_ventas` después de cada ejecución; no basta con comprobar que hay cero duplicados. Adjuntar evidencias de ambos conteos, el estado exitoso de los pipelines, los registros observados y la auditoría.

> **Situación del repositorio al preparar este ejemplo (23/10/2026):** ambas definiciones de pipelines en GitHub contienen actividades `state: "Inactive"`; por tanto la validación está **intencionalmente bloqueada** hasta sincronizar y confirmar sus versiones definitivas desde Fabric. El notebook 12 existe con directorio interno por ID, y se reconoce por su `.platform`.

## Seguridad y límites

No ejecuta `DROP`, no sobrescribe información Gold, no publica credenciales. No autoriza automáticamente sobrescribir cambios de workspace ni procesar borrados desde Git. Un `-Apply` inicia tareas reales y puede incurrir en consumo de Fabric. No usar credenciales de la cuenta de un evaluador con acceso a nuestros datos privados: otorgar acceso restringido al repositorio o entregar la automatización como código de ejemplo.

## Referencias Microsoft Learn

- [Git status](https://learn.microsoft.com/en-us/rest/api/fabric/core/git/get-status)
- [Git UpdateFromGit](https://learn.microsoft.com/en-us/rest/api/fabric/core/git/update-from-git)
- [Git connection](https://learn.microsoft.com/en-us/rest/api/fabric/core/git/get-connection)
- [Ejecutar pipeline](https://learn.microsoft.com/en-us/rest/api/fabric/datapipeline/background-jobs/run-on-demand-execute)
- [Consultar job](https://learn.microsoft.com/en-us/rest/api/fabric/core/job-scheduler/get-item-job-instance)
