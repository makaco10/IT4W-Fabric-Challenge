#Requires -Version 7.0
<#
.SYNOPSIS
  Release ligero de Nexo Retail / IT4W. Solo un workspace GitHub/Fabric conectado.
.DESCRIPTION
  Validate: inspeccion local de artefactos versionados (offline).
  Plan: lee estado de Git en Fabric (sin cambios).
  Deploy: actualiza items del workspace desde Git si no hay cambios locales ni conflictos.
  Run: ejecuta pipelines ya publicados mediante API Fabric y espera al fin.
  All: Deploy + Run (historico e incremental).
  Las acciones mutables requieren -Apply. No crea tenant, capacity, gateway ni SQL Server.
#>
[CmdletBinding()]
param(
    [ValidateSet('Validate','Plan','Deploy','Run','All')]
    [string]$Action = 'Validate',
    [ValidateSet('Historical','Incremental','Both')]
    [string]$Pipeline = 'Incremental',
    [string]$Configuration = (Join-Path $PSScriptRoot 'config.example.json'),
    [switch]$Apply
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ApiRoot = 'https://api.fabric.microsoft.com/v1'
$RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))

function Require-Condition([bool]$condition, [string]$explanation) {
    if (-not $condition) { throw $explanation }
}

function Safe-Field($obj, [string]$field) {
    if ($null -eq $obj) { return $null }
    $prop = $obj.PSObject.Properties[$field]
    if ($null -eq $prop) { return $null }
    return $prop.Value
}

function Read-Config {
    Require-Condition (Test-Path -LiteralPath $Configuration -PathType Leaf) "No existe configuracion: $Configuration"
    $cfg = Get-Content -LiteralPath $Configuration -Raw -Encoding UTF8 | ConvertFrom-Json
    $parsedGuid = [guid]::Empty
    Require-Condition ([guid]::TryParse([string]$cfg.workspaceId,[ref]$parsedGuid)) 'workspaceId debe ser GUID'
    foreach($key in @('githubOwner','githubRepo','githubBranch','githubDirectory','historicalPipeline','incrementalPipeline','incrementalDefaultPeriod')) {
        Require-Condition (-not [string]::IsNullOrWhiteSpace([string]$cfg.$key)) "Configuracion incompleta: $key"
    }
    return $cfg
}

function Check-Repository($cfg) {
    $expected = @(
        'README.md',
        'fabric/LH_IT4W_Development.Lakehouse/.platform',
        'fabric/NB_Consultas_Control.Notebook/notebook-content.sql',
        'fabric/PL_IT4W_Backfill_Historico.DataPipeline/pipeline-content.json',
        'fabric/PL_IT4W_Incremental_Mensual.DataPipeline/pipeline-content.json'
    )
    foreach ($name in $expected) {
        Require-Condition (Test-Path -LiteralPath (Join-Path $RepoRoot $name) -PathType Leaf) "Falta en Git: $name"
    }
    $notebookNames = Get-ChildItem -Path (Join-Path $RepoRoot 'fabric') -Filter '.platform' -Recurse -File |
        ForEach-Object { try { (Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json).metadata.displayName } catch { $null } }
    foreach ($name in @('NB_IT4W_00_Initialize_Contracts_PySpark','NB_IT4W_01_Landing_To_Bronze',
            'NB_IT4W_02_Bronze_To_Silver','NB_IT4W_03_Silver_To_Gold',
            'NB_IT4W_11_Landing_To_Bronze_Incremental','NB_IT4W_12_Bronze_To_Silver_Incremental',
            'NB_IT4W_13_Silver_To_Gold_Incremental')) {
        Require-Condition ($name -in $notebookNames) "No esta versionado el notebook: $name"
    }

    foreach ($pipelineName in @($cfg.historicalPipeline,$cfg.incrementalPipeline)) {
        $path = Join-Path $RepoRoot "fabric/$pipelineName.DataPipeline/pipeline-content.json"
        $pipe = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        Require-Condition ($pipe.properties.activities.Count -gt 0) "No hay actividades en $pipelineName"
        # Recorre actividades anidadas (por ejemplo, ForEach > Copy)
        $queue = [System.Collections.Queue]::new()
        foreach ($activity in @($pipe.properties.activities)) { $queue.Enqueue($activity) }
        $inactive = [System.Collections.Generic.List[string]]::new()
        while ($queue.Count -gt 0) {
            $a = $queue.Dequeue()
            if ([string](Safe-Field $a 'state') -eq 'Inactive') { $inactive.Add([string](Safe-Field $a 'name')) }
            $typeProperties = Safe-Field $a 'typeProperties'
            $children = Safe-Field $typeProperties 'activities'
            if ($null -ne $children) {
                foreach ($child in @($children)) { $queue.Enqueue($child) }
            }
        }
        Require-Condition ($inactive.Count -eq 0) "BLOQUEADO: $pipelineName tiene actividades Inactive: $($inactive -join ', '). Sincroniza Fabric hacia Git y repite Validate."
        if ($pipelineName -eq $cfg.incrementalPipeline) {
            Require-Condition ([string]$pipe.properties.parameters.p_periodo.defaultValue -eq [string]$cfg.incrementalDefaultPeriod) 'Periodo incremental predeterminado distinto al de config. La ejecucion API no cambia parametros por corrida.'
        }
        Write-Host "[OK] Pipeline versionado: $pipelineName ($($pipe.properties.activities.Count) actividades raiz)"
    }
    Write-Host '[OK] Contratos, notebooks y consultas encontrados en Git.'
}

function Get-AccessToken {
    Require-Condition ($null -ne (Get-Command az -ErrorAction SilentlyContinue)) 'Instala Azure CLI e inicia sesion: az login --allow-no-subscriptions'
    $accessToken = (& az account get-access-token --resource 'https://api.fabric.microsoft.com' --query accessToken -o tsv 2>$null)
    Require-Condition ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace([string]$accessToken)) 'Azure CLI no pudo emitir token de Fabric. Ejecuta az login --allow-no-subscriptions.'
    return [string]$accessToken
}

function Call-Fabric([string]$method, [string]$path, $payload = $null) {
    $uri = if ($path.StartsWith('https://')) { $path } else { "$ApiRoot/$($path.TrimStart('/'))" }
    Require-Condition ($uri.StartsWith('https://api.fabric.microsoft.com/v1/')) "URL no permitida: $uri"
    $headers = @{ Authorization = "Bearer $(Get-AccessToken)" }
    $params = @{ Uri=$uri; Method=$method; Headers=$headers; SkipHttpErrorCheck=$true; TimeoutSec=90 }
    if ($null -ne $payload) {
        $params['Body'] = (ConvertTo-Json -InputObject $payload -Depth 30 -Compress)
        $params['ContentType'] = 'application/json'
    }
    $resp = Invoke-WebRequest @params
    $raw = [string]$resp.Content
    if ([int]$resp.StatusCode -ge 300) { throw "Fabric API $method $uri devolvio HTTP $($resp.StatusCode): $raw" }
    $data = if (-not [string]::IsNullOrWhiteSpace($raw)) { $raw | ConvertFrom-Json } else { $null }
    return @{ Code = [int]$resp.StatusCode; Headers=$resp.Headers; Data=$data }
}

function Header-Value($headers,[string]$name) {
    $v=$headers[$name]
    if($null -eq $v){return ''}
    return [string](@($v)[0])
}

function Await-Operation($response) {
    if($response.Code -ne 202){return $response.Data}
    $id = Header-Value $response.Headers 'x-ms-operation-id'
    Require-Condition (-not [string]::IsNullOrWhiteSpace($id)) 'La operacion asíncrona no devolvio operation ID'
    for($i=0;$i -lt 60;$i++) {
        $delay = Header-Value $response.Headers 'Retry-After'
        $seconds=if($delay -match '^\d+$') {[Math]::Min([int]$delay,60)} else {10}
        Start-Sleep -Seconds ([Math]::Max(5,$seconds))
        $p=Call-Fabric 'GET' "operations/$id"
        Write-Host "Operacion Git: $($p.Data.status)"
        if ($p.Data.status -eq 'Succeeded') {
            return (Call-Fabric 'GET' "operations/$id/result").Data
        }
        if ($p.Data.status -in @('Failed','Cancelled')) { throw "Operacion Git fallida: $($p.Data | ConvertTo-Json -Compress -Depth 8)" }
    }
    throw 'Timeout esperando la operacion Git (10-60 minutos, segun Retry-After).'
}

function Get-Status($cfg) {
    $base = "workspaces/$($cfg.workspaceId)"
    $connect = (Call-Fabric 'GET' "$base/git/connection").Data
    Require-Condition ($connect.gitConnectionState -eq 'ConnectedAndInitialized') 'El workspace no tiene conexion Git inicializada.'
    $g = $connect.gitProviderDetails
    Require-Condition ($g.gitProviderType -eq 'GitHub') 'El workspace no apunta a GitHub.'
    Require-Condition ($g.ownerName -eq $cfg.githubOwner -and $g.repositoryName -eq $cfg.githubRepo -and $g.branchName -eq $cfg.githubBranch) 'Repositorio/branch de Fabric diferente del esperado.'
    Require-Condition (([string]$g.directoryName).Trim('/') -eq ([string]$cfg.githubDirectory).Trim('/')) 'Directorio de Fabric diferente al esperado.'
    $resp = Call-Fabric 'GET' "$base/git/status"
    return (Await-Operation $resp)
}

function Review-Status($state) {
    $blockers = @()
    $changes = @((Safe-Field $state 'changes') | Where-Object { $null -ne $_ })
    foreach($ch in $changes) {
        $name=[string](Safe-Field (Safe-Field $ch 'itemMetadata') 'displayName')
        $conflict=[string](Safe-Field $ch 'conflictType')
        $workspaceChange=[string](Safe-Field $ch 'workspaceChange')
        $remoteChange=[string](Safe-Field $ch 'remoteChange')
        if ($conflict -notin @('','None')) { $blockers += "Conflicto: $name" }
        if ($workspaceChange -notin @('','None')) { $blockers += "Cambio sin publicar en workspace: $name" }
        if ($remoteChange -eq 'Deleted') { $blockers += "Borrado remoto: $name" }
    }
    Write-Host "WorkspaceHead: $($state.workspaceHead); RemoteCommit: $($state.remoteCommitHash); cambios: $($changes.Count)"
    foreach($x in $changes) {Write-Host ('  {0}: remoto={1} workspace={2} conflicto={3}' -f (Safe-Field (Safe-Field $x 'itemMetadata') 'displayName'), (Safe-Field $x 'remoteChange'), (Safe-Field $x 'workspaceChange'), (Safe-Field $x 'conflictType'))}
    foreach($b in $blockers) {Write-Warning $b}
    return $blockers
}

function Deploy-FromGit($cfg) {
    $state = Get-Status $cfg
    $blockers = @(Review-Status $state)
    Require-Condition ($blockers.Count -eq 0) 'No se despliega: hay cambios/conflictos/borrados por resolver manualmente.'
    Require-Condition (-not [string]::IsNullOrWhiteSpace([string]$state.remoteCommitHash)) 'Sin SHA remoto conocido.'
    if($state.changes.Count -eq 0) { Write-Host '[OK] Git y workspace ya sincronizados.'; return }
    $payload = @{
        workspaceHead=$state.workspaceHead
        remoteCommitHash=$state.remoteCommitHash
        options=@{ allowOverrideItems=$true }
    }
    if(-not $Apply) { Write-Host '[DRY RUN] Sincronizacion autorizable. Agrega -Apply para sincronizar.'; return }
    $resp = Call-Fabric 'POST' "workspaces/$($cfg.workspaceId)/git/updateFromGit" $payload
    $null = Await-Operation $resp
    Write-Host '[OK] UpdateFromGit completado. Revalidar conexion y dependencias si aparecen errores de configuracion.'
}

function Get-PipelineId($cfg,[string]$name) {
    $uri="workspaces/$($cfg.workspaceId)/items?type=DataPipeline"
    $all=@()
    do {
        $page = (Call-Fabric 'GET' $uri).Data
        $all += @($page.value)
        $continuation = [string](Safe-Field $page 'continuationToken')
        $uri = if ([string]::IsNullOrWhiteSpace($continuation)) { '' } else { "workspaces/$($cfg.workspaceId)/items?type=DataPipeline&continuationToken=$([uri]::EscapeDataString($continuation))" }
    } while($uri)
    $found=@($all | Where-Object { $_.displayName -eq $name })
    Require-Condition ($found.Count -eq 1) "No se encontro exactamente un pipeline $name en Fabric."
    return [string]$found[0].id
}

function Run-Pipeline($cfg,[string]$name) {
    $id=Get-PipelineId $cfg $name
    if(-not $Apply) {Write-Host "[DRY RUN] Ejecutaria $name, id=$id. Agrega -Apply.";return}
    Write-Host "Lanzando $name ($id) ..."
    # API especifica de DataPipeline; no lleva parametros ad hoc.
    $response = Call-Fabric 'POST' "workspaces/$($cfg.workspaceId)/dataPipelines/$id/jobs/execute/instances"
    Require-Condition ($response.Code -eq 202) 'Fabric no inicio la ejecucion (no recibimos HTTP 202).'
    $location=Header-Value $response.Headers 'Location'
    Require-Condition (-not [string]::IsNullOrWhiteSpace($location)) 'No se devolvio Location del job'
    $firstWait=Header-Value $response.Headers 'Retry-After'
    $seconds=if($firstWait -match '^\d+$') {[Math]::Min([int]$firstWait,60)} else {10}
    Start-Sleep -Seconds ([Math]::Max(5,$seconds))
    for($i=0;$i -lt 360;$i++) {
        $r=Call-Fabric 'GET' $location
        $status=[string]$r.Data.status
        Write-Host "$name -> $status"
        if($status -eq 'Completed') {Write-Host "[OK] $name completado. Job=$($r.Data.id)";return}
        if($status -in @('Failed','Cancelled','Deduped')) {throw "Pipeline $name termino $status : $($r.Data | ConvertTo-Json -Compress -Depth 8)"}
        Require-Condition ($status -in @('NotStarted','InProgress')) "Estado desconocido de job: $status"
        Start-Sleep -Seconds 10
    }
    throw "Tiempo limite de seguimiento del job: $name"
}

try {
    $cfg=Read-Config
    if($Action -in @('Validate','Deploy','All')) {Check-Repository $cfg}
    switch($Action) {
        'Validate' {Write-Host '[OK] Validacion local completa.'}
        'Plan' {
            $status = Get-Status $cfg
            $blockers=@(Review-Status $status)
            if($blockers.Count -gt 0){throw 'Plan BLOQUEADO: resolver cambios antes de deploy.'}
            Write-Host '[OK] Plan sin conflictos destructivos.'
        }
        'Deploy' {Deploy-FromGit $cfg}
        'Run' {
            $items = switch($Pipeline){'Historical'{@($cfg.historicalPipeline)} 'Incremental'{@($cfg.incrementalPipeline)} 'Both'{@($cfg.historicalPipeline,$cfg.incrementalPipeline)}}
            foreach($p in $items){ Run-Pipeline $cfg $p }
        }
        'All' {
            Require-Condition $Apply 'All requiere -Apply para ejecutar sincronizacion y procesamiento. Ejecuta primero Validate y Plan.'
            Deploy-FromGit $cfg
            foreach($p in @($cfg.historicalPipeline,$cfg.incrementalPipeline)){Run-Pipeline $cfg $p}
        }
    }
} catch {
    Write-Error "IT4W Release: $($_.Exception.Message)" -ErrorAction Continue
    exit 1
}
